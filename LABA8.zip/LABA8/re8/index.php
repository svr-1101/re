<?php
session_start();

/* ---------- ИНИЦИАЛИЗАЦИЯ ---------- */
$errors = [];

/* ---------- ВКЛАДКИ ---------- */
if (isset($_GET['tab'])) {
    $_SESSION['active_tab'] = (int)$_GET['tab'];
}

/* ---------- КАЛЕНДАРЬ ---------- */
if (isset($_POST['month']) || isset($_POST['year'])) {
    $_SESSION['calendar_month'] = $_POST['month'] ?? date('n');
    $_SESSION['calendar_year']  = $_POST['year'] ?? date('Y');
    $_SESSION['active_tab'] = 2;
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

/* ---------- РЕГИСТРАЦИЯ ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {

    $fullname  = htmlspecialchars(trim($_POST['fullname'] ?? ''));
    $login     = htmlspecialchars(trim($_POST['login'] ?? ''));
    $password  = $_POST['password'] ?? '';
    $birthdate = $_POST['birthdate'] ?? '';

    if (strlen($fullname) < 5) $errors[] = "ФИО должно содержать минимум 5 символов";
    if (strlen($login) < 3)    $errors[] = "Логин должен содержать минимум 3 символа";
    if (strlen($password) < 6) $errors[] = "Пароль должен содержать минимум 6 символов";
    if (empty($birthdate))     $errors[] = "Укажите дату рождения";

    if (empty($errors)) {
        $_SESSION['success'] = true;
        $_SESSION['active_tab'] = 3;
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    } else {
        $_SESSION['active_tab'] = 3;
    }
}

/* ---------- ПЕРЕМЕННЫЕ ---------- */
$active_tab = $_SESSION['active_tab'] ?? 1;
$month = $_SESSION['calendar_month'] ?? date('n');
$year  = $_SESSION['calendar_year'] ?? date('Y');
$success = $_SESSION['success'] ?? false;
unset($_SESSION['success']);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Лабораторная работа №8</title>

<style>
body {
    margin: 0;
    padding: 30px;
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #fbc2eb, #a6c1ee);
}

.container {
    max-width: 1000px;
    margin: auto;
}

.header {
    background: white;
    padding: 25px;
    border-radius: 12px;
    text-align: center;
    margin-bottom: 20px;
}

.header h1 {
    margin: 0;
    color: #6a1b9a;
}

.buttons {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-bottom: 20px;
}

.buttons button {
    padding: 10px 20px;
    background: #ba68c8;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}

.content {
    background: white;
    padding: 25px;
    border-radius: 12px;
}

.task {
    display: none;
}

.task.active {
    display: block;
}

h2 {
    text-align: center;
    color: #6a1b9a;
    margin-bottom: 20px;
}

/* ТАБЛИЦЫ */
table {
    border-collapse: collapse;
    margin: auto;
}

th, td {
    border: 1px solid #ccc;
    padding: 8px 12px;
    text-align: center;
}

th {
    background: #ce93d8;
    color: white;
}

/* КАЛЕНДАРЬ */
.calendar .weekend {
    background: #f8bbd0;
    font-weight: bold;
}

.calendar .holiday {
    background: #f48fb1;
    color: #880e4f;
    font-weight: bold;
}

/* ФОРМА */
form {
    max-width: 400px;
    margin: auto;
}

.form-group {
    margin-bottom: 15px;
}

label {
    display: block;
    margin-bottom: 5px;
    color: #6a1b9a;
}

input {
    width: 100%;
    padding: 8px;
}

button.submit {
    width: 100%;
    padding: 10px;
    background: #ba68c8;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}

.error {
    background: #ffe6e6;
    padding: 10px;
    margin-bottom: 15px;
    color: red;
    border-radius: 6px;
}

.success {
    background: #c8e6c9;
    padding: 10px;
    text-align: center;
    border-radius: 6px;
    margin-bottom: 15px;
}
</style>
</head>

<body>

<div class="container">

<div class="header">
    <h1>Лабораторная работа №8</h1>
    <p>PHP. Таблица, календарь, форма</p>
</div>

<div class="buttons">
    <button onclick="location.href='?tab=1'">Таблица</button>
    <button onclick="location.href='?tab=2'">Календарь</button>
    <button onclick="location.href='?tab=3'">Регистрация</button>
</div>

<div class="content">

<!-- ЗАДАНИЕ 1 -->
<div class="task <?= $active_tab==1?'active':'' ?>">
<h2>Таблица умножения</h2>
<table>
<tr><th>×</th><?php for($i=1;$i<=10;$i++) echo "<th>$i</th>"; ?></tr>
<?php
for($i=1;$i<=10;$i++){
    echo "<tr><th>$i</th>";
    for($j=1;$j<=10;$j++) echo "<td>".($i*$j)."</td>";
    echo "</tr>";
}
?>
</table>
</div>

<!-- ЗАДАНИЕ 2 -->
<div class="task <?= $active_tab==2?'active':'' ?>">
<h2>Календарь</h2>

<form method="post" style="text-align:center;">
<select name="month" onchange="this.form.submit()">
<?php
$months=['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
foreach($months as $k=>$v){
    $sel=$month==$k+1?'selected':'';
    echo "<option value='".($k+1)."' $sel>$v</option>";
}
?>
</select>

<select name="year" onchange="this.form.submit()">
<?php
for($y=2020;$y<=2030;$y++){
    $sel=$year==$y?'selected':'';
    echo "<option $sel>$y</option>";
}
?>
</select>
</form>

<div class="calendar">
<?php
$days=date('t',mktime(0,0,0,$month,1,$year));
$first=date('w',mktime(0,0,0,$month,1,$year));
$first=$first==0?6:$first-1;
$holidays=["$month-1","$month-7"];

echo "<table><tr>
<th>Пн</th><th>Вт</th><th>Ср</th><th>Чт</th>
<th>Пт</th><th>Сб</th><th>Вс</th></tr><tr>";

for($i=0;$i<$first;$i++) echo "<td></td>";

for($d=1;$d<=$days;$d++){
    $dow=($first+$d-1)%7;
    $class='';
    if($dow>=5) $class='weekend';
    if(in_array("$month-$d",$holidays)) $class='holiday';
    echo "<td class='$class'>$d</td>";
    if(($first+$d)%7==0) echo "</tr><tr>";
}
echo "</tr></table>";
?>
</div>
</div>

<!-- ЗАДАНИЕ 3 -->
<div class="task <?= $active_tab==3?'active':'' ?>">
<h2>Регистрация</h2>

<?php if($success): ?>
<div class="success">Регистрация прошла успешно</div>
<?php endif; ?>

<?php if(!empty($errors)): ?>
<div class="error"><?php foreach($errors as $e) echo "<div>$e</div>"; ?></div>
<?php endif; ?>

<form method="post">
<div class="form-group">
<label>ФИО</label>
<input type="text" name="fullname" required>
</div>

<div class="form-group">
<label>Логин</label>
<input type="text" name="login" required>
</div>

<div class="form-group">
<label>Пароль</label>
<input type="password" name="password" required>
</div>

<div class="form-group">
<label>Дата рождения</label>
<input type="date" name="birthdate" required>
</div>

<button type="submit" name="register" class="submit">Зарегистрироваться</button>
</form>
</div>

</div>
</div>

</body>
</html>
