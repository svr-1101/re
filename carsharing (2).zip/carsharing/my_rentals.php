<?php
require_once 'db.php';
require_once 'header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT r.*, c.brand, c.model, c.license_plate, p.id as payment_id, p.payment_date
        FROM rentals r
        JOIN cars c ON r.car_id = c.id
        LEFT JOIN payments p ON r.id = p.rental_id
        WHERE r.user_id = ?
        ORDER BY r.start_time DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<div class="container">
    <h2>Мои поездки</h2>
    <?php if ($result->num_rows > 0): ?>
        <table style="width: 100%; border-collapse: collapse; border: 1px solid #ddd; margin-bottom: 30px;">
            <thead style="background: #f8f9fa;">
                <tr>
                    <th style="padding: 10px; text-align: left;">Автомобиль</th>
                    <th style="padding: 10px; text-align: left;">Дата начала</th>
                    <th style="padding: 10px; text-align: left;">Дата конца</th>
                    <th style="padding: 10px; text-align: left;">Стоимость</th>
                    <th style="padding: 10px; text-align: left;">Статус</th>
                    <th style="padding: 10px; text-align: left;">Действия</th>
                </tr>
            </thead>
            <tbody>
            <?php while($row = $result->fetch_assoc()): 
                $start_time = date("d.m.Y H:i", strtotime($row['start_time']));
                $end_time = $row['end_time'] ? date("d.m.Y H:i", strtotime($row['end_time'])) : '—';
                $status = ($row['status'] == 'active') ? 'Активна' : 'Завершена';
                $payment_status = $row['payment_id'] ? true : false;
                $total_price = $row['total_price'] ? number_format($row['total_price'], 0, ',', ' ') . ' ₽' : '—';
            ?>
                <tr style="border-bottom: 1px solid #ddd;">
                    <td style="padding: 10px;"><?php echo htmlspecialchars($row['brand'] . ' ' . $row['model']); ?></td>
                    <td style="padding: 10px;"><?php echo $start_time; ?></td>
                    <td style="padding: 10px;"><?php echo $end_time; ?></td>
                    <td style="padding: 10px;"><?php echo $total_price; ?></td>
                    <td style="padding: 10px;"><?php echo $status; ?></td>
                    <td style="padding: 10px;">
                        <?php if ($row['status'] == 'active'): ?>
                            <a href="finish_rent.php?id=<?php echo $row['id']; ?>" style="color: #ff6b6b; font-size: 0.9em;">Завершить</a>
                        <?php elseif (!$payment_status): ?>                           
                            <a href="pay.php?rental_id=<?php echo $row['id']; ?>" style="background: #28a745; color: #000; padding: 5px 10px; width: auto; display:inline-block;">Оплатить</a>
                        <?php else: ?>
                            <span style="color: grey; font-size: 0.9em;">Оплачено</span>
                            <br>
                            <a href="leave_review.php?car_id=<?php echo $row['car_id']; ?>" style="font-size: 0.85em; color: blue; text-decoration: underline;">Оставить отзыв</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Поездок пока нет.</p>
    <?php endif; ?>
</div>

<?php require_once 'footer.php'; ?>