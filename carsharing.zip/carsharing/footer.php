</div> <!-- Конец container -->
    <footer style="background: #333; color: #fff; text-align: center; padding: 20px; margin-top: 40px;">
        <p>&copy; 2024 Курсовая работа "Каршеринг"</p>
    </footer>
</body>
</html>